#include <stdio.h>
#include <stdlib.h>
#include <string.h> 
#include "multiciclo_biblioteca.h"




void Carregar_Memoria_Instrucoes_e_Dados(struct instrucao *nome_inst){
    char nomepasta[100];
    printf("Digite o nome do arquivo .mem: ");
    scanf("%s", nomepasta);

    FILE *file = fopen(nomepasta,"r");
    if(file == NULL){
        printf("Arquivo nao encontrado\n");
        return;
    } else {
        printf("Memória de instruções carregada\n");
    }

    // Inicializa todos os 256 opcodes como -1, sinalizando espaço vazio
    for(int i = 0; i < 256; i++){
        nome_inst[i].opcode = -1;
        nome_inst[i].dado = 0;
        for (int j = 0; j < 17; j++) nome_inst[i].inst_char[j] = '\0';
        for (int j = 0; j < 17; j++) nome_inst[i].dado_char[j] = '\0';
    }

    int posicao = 0;
    int lendoDados = 0; // flag para alternar entre instruções e dados
    char linha[100];    // buffer temporário para leitura linha a linha

    // Leitura do arquivo linha por linha
    while(fgets(linha, sizeof(linha), file)){
        // Remove \n e \r (compatível Windows, Linux)
        linha[strcspn(linha, "\r\n")] = '\0';

        // Pula linhas vazias
        if (strlen(linha) == 0) continue;

        if (strcmp(linha, ".data") == 0) {
            lendoDados = 1; // ao encontrar ".data", muda para modo leitura de dados
            continue;
        }

        if (!lendoDados) {
            // ======================= LEITURA DE INSTRUÇÕES =========================

            // Verifica se 'linha' tem 16 bits válidos (só '0' e '1')
            int valido = 1;
            if (strlen(linha) != 16) valido = 0;
            else {
                for (int k = 0; k < 16; k++) {
                    if (linha[k] != '0' && linha[k] != '1') {
                        valido = 0;
                        break;
                    }
                }
            }
            if (!valido) {
                printf("Linha inválida ignorada: '%s' (tam %ld)\n", linha, strlen(linha));
                continue;
            }

            strncpy(nome_inst[posicao].inst_char, linha, 16);
            nome_inst[posicao].inst_char[16] = '\0';

            char opcode[5] = {0};
            strncpy(opcode, nome_inst[posicao].inst_char, 4);
            unsigned int opcode_num = (unsigned int)strtol(opcode, NULL, 2);

            if(opcode_num == 11){ // Tipo I LW
                char rs[4] = {0}, rt[4] = {0}, imm[7] = {0};
                strncpy(rs, nome_inst[posicao].inst_char + 4, 3);
                strncpy(rt, nome_inst[posicao].inst_char + 7, 3);
                strncpy(imm, nome_inst[posicao].inst_char + 10, 6);

                nome_inst[posicao].opcode = opcode_num;
                nome_inst[posicao].rs = (int)strtol(rs, NULL, 2);
                nome_inst[posicao].rt = (int)strtol(rt, NULL, 2);
                nome_inst[posicao].imm = (int)strtol(imm, NULL, 2);
            }
            else if(opcode_num == 15){ // Tipo I SW
                char rs[4] = {0}, rt[4] = {0}, imm[7] = {0};
                strncpy(rs, nome_inst[posicao].inst_char + 4, 3);
                strncpy(rt, nome_inst[posicao].inst_char + 7, 3);
                strncpy(imm, nome_inst[posicao].inst_char + 10, 6);

                nome_inst[posicao].opcode = opcode_num;
                nome_inst[posicao].rs = (int)strtol(rs, NULL, 2);
                nome_inst[posicao].rt = (int)strtol(rt, NULL, 2);
                nome_inst[posicao].imm = (int)strtol(imm, NULL, 2);
            }
            else if(opcode_num == 8){ // Tipo I BEQ
                char rs[4] = {0}, rt[4] = {0}, imm[7] = {0};
                strncpy(rs, nome_inst[posicao].inst_char + 4, 3);
                strncpy(rt, nome_inst[posicao].inst_char + 7, 3);
                strncpy(imm, nome_inst[posicao].inst_char + 10, 6);

                if (imm[0] == '1') {
                    imm[0] = '0';
                    for(int i = 1; i <= 5; i++) {
                        imm[i] = (imm[i] == '1') ? '0' : '1';
                    }
                    nome_inst[posicao].imm = (int)strtol(imm, NULL, 2);
                    nome_inst[posicao].imm = -(nome_inst[posicao].imm + 1);
                } else {
                    nome_inst[posicao].imm = (int)strtol(imm, NULL, 2);
                }

                nome_inst[posicao].opcode = opcode_num;
                nome_inst[posicao].rs = (int)strtol(rs, NULL, 2);
                nome_inst[posicao].rt = (int)strtol(rt, NULL, 2);
            }
            else if(opcode_num == 2){ // Tipo J
                char addr[8] = {0};
                strncpy(addr, nome_inst[posicao].inst_char + 9, 7);
                nome_inst[posicao].opcode = opcode_num;
                nome_inst[posicao].addr = (int)strtol(addr, NULL, 2);
            }
            else if(opcode_num == 0){ // Tipo R
                char rs[4] = {0}, rt[4] = {0}, rd[4] = {0}, funct[4] = {0};
                strncpy(rs, nome_inst[posicao].inst_char + 4, 3);
                strncpy(rt, nome_inst[posicao].inst_char + 7, 3);
                strncpy(rd, nome_inst[posicao].inst_char + 10, 3);
                strncpy(funct, nome_inst[posicao].inst_char + 13, 3);

                nome_inst[posicao].opcode = opcode_num;
                nome_inst[posicao].rs = (int)strtol(rs, NULL, 2);
                nome_inst[posicao].rt = (int)strtol(rt, NULL, 2);
                nome_inst[posicao].rd = (int)strtol(rd, NULL, 2);
                nome_inst[posicao].funct = (int)strtol(funct, NULL, 2);
            }
        else if(opcode_num == 4){ // Tipo I ADDI
    char rs[4] = {0}, rt[4] = {0}, imm[7] = {0};
    strncpy(rs, nome_inst[posicao].inst_char + 4, 3);
    strncpy(rt, nome_inst[posicao].inst_char + 7, 3);
    strncpy(imm, nome_inst[posicao].inst_char + 10, 6);
    imm[6] = '\0';

    nome_inst[posicao].opcode = opcode_num;
    nome_inst[posicao].rs = (int)strtol(rs, NULL, 2);
    nome_inst[posicao].rt = (int)strtol(rt, NULL, 2);
    nome_inst[posicao].imm = (int)strtol(imm, NULL, 2); // Apenas converte direto
}

            else {
                printf("Tipo de instrução não identificada. Opcode %i Bin: %s\n", opcode_num, nome_inst[posicao].inst_char);
            }

            posicao++;
            if(posicao >= 256){
                printf("Limite máximo de instruções atingido\n");
                break;
            }

        } else {
            // ======================= LEITURA DOS DADOS =========================
            int endereco;
            char valor_bin[17]; // espaço para 16 bits + '\0'

            // Lê linha no formato: "endereco:valor_binario"
            if (sscanf(linha, "%d:%16s", &endereco, valor_bin) == 2) {
                int valor = (int)strtol(valor_bin, NULL, 2);

                // Converte complemento de dois se necessário
                if (valor_bin[0] == '1' && strlen(valor_bin) == 16) {
                    char invertido[17];
                    for (int i = 0; i < 16; i++) {
                        invertido[i] = (valor_bin[i] == '1') ? '0' : '1';
                    }
                    invertido[16] = '\0';
                    valor = (int)strtol(invertido, NULL, 2);
                    valor = -(valor + 1);
                }

                if (endereco >= 128 && endereco < 256) {  // valida endereço
                    nome_inst[endereco].dado = valor;                    // armazena valor decimal
                    strncpy(nome_inst[endereco].dado_char, valor_bin, 16); // armazena binário em dado_char
                    nome_inst[endereco].dado_char[16] = '\0';
                }
            }
        }
    }

    fclose(file);
    printf("[OK] Memória carregada.\n");
}

int novaULA(int A, int B, int operacao, int* zero) {
    int resultado;
    *zero = 0;

    switch (operacao) {
        case 0: // ADD
            resultado = A + B;
               if (resultado > 127 || resultado < -128) { 
                printf("Overflow na subtração! Resultado: %d\n", resultado);
            }
            break;
        case 2: // SUB
            resultado = A - B;
               if (resultado > 127 || resultado < -128) { 
                printf("Overflow na subtração! Resultado: %d\n", resultado);
            }
            break;
        case 4: // AND
            resultado = A & B;
            break;
        case 5: // OR
            resultado = A | B;
            break;
        default:
            printf("Operação inválida!\n");
            resultado = 0;
    }

     // A ULA seta o sinal zero se resultado == 0
    if (resultado == 0) {
        *zero = 1;
    } else {
        *zero = 0;
    }
    

    return resultado;
}


int Ler_Registrador(int *banco_de_registradores, int indice) {
    if (indice >= 0 && indice < 8) {
        return banco_de_registradores[indice];
    } else {
        printf("Índice de registrador não encontrado\n");
        return -1;
    }
}

void Escrever_Registrador(int *banco_de_registradores, int indice, int valor) {
    if (indice >= 0 && indice < 8) {
        banco_de_registradores[indice] = valor;
    } else {
        printf("Índice de registrador inválido\n");
    }
}


void Imprimir_bancoRG(int *banco_de_registradores) {
    printf("**********BANCO DE REGISTRADORES***********\n\n");
    for (int i = 0; i < 8; i++) {
        printf("RG[%i] = %i\n", i, banco_de_registradores[i]);
    }
    printf("\n");
}

int Ler_M_Dados(int endereco, struct instrucao *nome_inst){
    if (endereco < 128 || endereco >= 256) {
        printf("\tEndereco invalido.\n");
    }
    return nome_inst[endereco].dado; // Retorna o dado no endere�o
}


void Escrever_M_Dados(int endereco, int valor, struct instrucao *nome_inst){

    if (endereco < 128|| endereco >= 256) {
        printf("\tEndereco invalido.\n");
    }
    nome_inst[endereco].dado = valor; // Armazena o valor no endere�o
}

void Imprimir_Memorias_Instrucoes_e_Dados(struct instrucao *nome_inst) {
    // =================== IMPRESSÃO DAS INSTRUÇÕES ======================
    printf("\n=== Memória de Instruções (0 a 127) ===\n"); // ADICIONADO

    for (int i = 0; i < 128; i++) {
        printf("Instrução %d:\t", i); // Mostra sempre o índice da instrução (MODIFICADO)

        // Verifica se 'inst_char' tem 16 bits válidos (só '0' e '1')
        int valido = 1;
        for (int k = 0; k < 16; k++) {
            if (nome_inst[i].inst_char[k] != '0' && nome_inst[i].inst_char[k] != '1') {
                valido = 0;
                break;
            }
        }

        if (!valido || nome_inst[i].opcode == -1) {
            printf("--\n"); // MODIFICADO: mostra "--" para instruções vazias ou inválidas
            continue;
        }

        printf("Assembly: ");

        if (nome_inst[i].opcode == 0) {
            switch (nome_inst[i].funct) {
                case 0: printf("add $t%d, $t%d, $t%d\t", nome_inst[i].rd, nome_inst[i].rs, nome_inst[i].rt); break;
                case 2: printf("sub $t%d, $t%d, $t%d\t", nome_inst[i].rd, nome_inst[i].rs, nome_inst[i].rt); break;
                case 4: printf("and $t%d, $t%d, $t%d\t", nome_inst[i].rd, nome_inst[i].rs, nome_inst[i].rt); break;
                case 5: printf("or $t%d, $t%d, $t%d\t", nome_inst[i].rd, nome_inst[i].rs, nome_inst[i].rt); break;
                default: printf("funct %d desconhecido\t", nome_inst[i].funct);
            }
        }
        else if (nome_inst[i].opcode == 11) {  // lw
            printf("lw $t%d, %d($t%d)\t", nome_inst[i].rt, nome_inst[i].imm, nome_inst[i].rs);
        }
        else if (nome_inst[i].opcode == 15) {  // sw
            printf("sw $t%d, %d($t%d)\t", nome_inst[i].rt, nome_inst[i].imm, nome_inst[i].rs);
        }
        else if (nome_inst[i].opcode == 4) {  // addi
            printf("addi $t%d, $t%d, %d\t", nome_inst[i].rt, nome_inst[i].rs, nome_inst[i].imm);
        }
        else if (nome_inst[i].opcode == 8) {  // beq
            printf("beq $t%d, $t%d, %d\t", nome_inst[i].rs, nome_inst[i].rt, nome_inst[i].imm);
        }
        else if (nome_inst[i].opcode == 2) {  // j
            printf("j %d\t", nome_inst[i].addr);
        }
        else {
            printf("Opcode %d desconhecido\t", nome_inst[i].opcode);
        }

        printf("Binário: ");
        for (int j = 0; j < 16; j++) {
            printf("%c", nome_inst[i].inst_char[j]);
        }

        unsigned int instrucao_hex = (unsigned int)strtol(nome_inst[i].inst_char, NULL, 2);
        printf("\tHexadecimal: %04X\n\n", instrucao_hex);
    }

    // =================== IMPRESSÃO DA MEMÓRIA DE DADOS ======================
    printf("\n=== Memória de Dados (128 a 255) ===\n"); // MODIFICADO
    for (int x = 0; x < 8; x++) {
        for (int y = 0; y < 16; y++) {
            int mem = 128 + x * 16 + y; // MODIFICADO: começa de 128
            if (nome_inst[mem].dado != 0) {
                printf("Mem[%i] %i\t", mem, nome_inst[mem].dado);
            } else {
                printf("Mem[%i] 0\t", mem); // MODIFICADO: mostra 0 nos vazios (em vez de --)
            }
        }
        printf("\n");
    }
}

void Executar_Ciclo(
    int *reg_dado,
    struct ULA_saida *saida,
    int *reg_A,
    int *reg_B,
    int *estado_atual,
    int *PC,
    struct instrucao *RI,
    struct instrucao *nome_inst,
    int *banco_de_registradores
) {
    int zero = 0;

    // Estado 0 – Busca da instrução + PC = PC + 1 (feito pela ULA)
    if (*estado_atual == 0) {
        saida->reg_ULA = 0;
        saida->flag = 0;
        if (nome_inst[*PC].opcode != -1) {
            *RI = nome_inst[*PC];
            *PC = novaULA(*PC, 1, 0, &zero); // PC = PC + 1 via ULA
        }
    }

    // Estado 1 – Decodificação da instrução e leitura dos registradores
    else if (*estado_atual == 1) {
        *reg_A = Ler_Registrador(banco_de_registradores, RI->rs);
        *reg_B = Ler_Registrador(banco_de_registradores, RI->rt);
    }

    // Estado 2 – Execução (ADDI, LW, SW)
    else if (*estado_atual == 2 &&
            (RI->opcode == 4 || RI->opcode == 11 || RI->opcode == 15)) {
        saida->reg_ULA = novaULA(*reg_A, RI->imm, 0, &zero); // ADD
    }

    // Estado 3 – Leitura de Memória (LW)
    else if (*estado_atual == 3 && RI->opcode == 11) {
        *reg_dado = Ler_M_Dados(saida->reg_ULA, nome_inst);
    }

    // Estado 4 – Escrita em registrador (LW)
    else if (*estado_atual == 4 && RI->opcode == 11) {
        Escrever_Registrador(banco_de_registradores, RI->rt, *reg_dado);
    }

    // Estado 5 – Escrita na memória (SW)
    else if (*estado_atual == 5 && RI->opcode == 15) {
        Escrever_M_Dados(saida->reg_ULA, *reg_B, nome_inst);
        *reg_dado = Ler_M_Dados(saida->reg_ULA, nome_inst); // leitura para verificação
    }

    // Estado 6 – Escrita do resultado imediato (ADDI)
    else if (*estado_atual == 6 && RI->opcode == 4) {
        Escrever_Registrador(banco_de_registradores, RI->rt, saida->reg_ULA);
    }

    // Estado 7 – Execução da ULA (Tipo R)
    else if (*estado_atual == 7 && RI->opcode == 0) {
        saida->reg_ULA = novaULA(*reg_A, *reg_B, RI->funct, &zero);
    }

    // Estado 8 – Escrita no registrador rd (Tipo R)
    else if (*estado_atual == 8 && RI->opcode == 0) {
        Escrever_Registrador(banco_de_registradores, RI->rd, saida->reg_ULA);
    }

    // Estado 9 – BEQ
    else if (*estado_atual == 9 && RI->opcode == 8) {
        novaULA(*reg_A, *reg_B, 2, &zero); // SUB
        saida->flag = zero;
        if (saida->flag == 1) {
            *PC = novaULA(*PC, RI->imm, 0, &zero); // PC = PC + offset
        }
        // Senão, mantém o PC (já foi incrementado no estado 0)
    }

    // Estado 10 – Jump (PC recebe RI->addr diretamente)
    else if (*estado_atual == 10 && RI->opcode == 2) {
        *PC = RI->addr;
    }
}


void ESTADOS(int *estado_atual, struct instrucao *RI){
    switch(*estado_atual) {
        case 0:
            // Estado inicial: busca a próxima instrução
            *estado_atual = 1;
            break;

        case 1:
            // Decodifica instrução e decide próximo estado com base no opcode

            if(RI->opcode == 0) {          // Tipo R
                *estado_atual = 7;
            }
            else if(RI->opcode == 15 ||    // Tipo I: SW, LW, ADDI
                    RI->opcode == 11 || 
                    RI->opcode == 4) {
                *estado_atual = 2;
            }
            if(RI->opcode == 8) {          // BEQ
                *estado_atual = 9;
            }
            if(RI->opcode == 2) {          // Jump
                *estado_atual = 10;
            }
            break;

        case 2:
            // Execução da instrução tipo I

            if(RI->opcode == 15) {         // SW - escrita em memória
                *estado_atual = 5;
            } else if(RI->opcode == 11) {  // LW - leitura da memória
                *estado_atual = 3;
            } else if(RI->opcode == 4) {   // ADDI - execução da operação
                *estado_atual = 6;
            }
            break;

        case 3:
            // Estado de acesso à memória para LW
            *estado_atual = 4;
            break;

        case 4:
            // Estado de escrita no registrador para LW, volta para busca
            *estado_atual = 0;
            break;

        case 5:
            // Estado de escrita em memória para SW, volta para busca
            *estado_atual = 0;
            break;

        case 6:
            // Estado de escrita no registrador para ADDI, volta para busca
            *estado_atual = 0;
            break;

        case 7:
            // Execução da instrução tipo R
            *estado_atual = 8;
            break;

        case 8:
            // Escrita do resultado da operação tipo R, volta para busca
            *estado_atual = 0;
            break;

        case 9:
            // Execução da instrução BEQ, volta para busca
            *estado_atual = 0;
            break;

        case 10:
            // Execução da instrução Jump, volta para busca
            *estado_atual = 0;
            break;

        default:
            printf("Estado desconhecido!\n");
            break;
    }
}

void salvar_estado(int *PC, struct instrucao *nome_inst, int *reg_dado, int *reg_A, int *reg_B, int *estado_atual, int *banco_de_registradores, struct ULA_saida *saida, struct instrucao *RI, struct estado_salvo *salvo, struct instrucao *copia_RI, struct ULA_saida *copia_saida){

    salvo->cop_PC = *PC;
    salvo->cop_RGdados = *reg_dado;
    salvo->cop_RGa = *reg_A;
    salvo->cop_RGb = *reg_B;
    salvo->cop_estado_c = *estado_atual;

    for (int i = 0; i < 8; i++) {
        salvo->cop_banco_de_registradores[i] = banco_de_registradores[i];
    }

    for (int i = 0; i < 256; i++) {
        salvo->cop_memoria[i] = nome_inst[i];
    }

    salvo->cop_saida = *saida;
    salvo->cop_RI = *RI;

    printf("Foi salvo -- teste!\n");
}


// Função que restaura o estado salvo de um nodo da pilha para as variáveis atuais do processador
void restaurar_estado(int *PC, int *reg_dado, int *reg_A, int *reg_B, int *estado_atual, int *banco_de_registradores, 
                      struct instrucao *nome_inst, struct ULA_saida *saida, struct instrucao *RI, struct estado_salvo *salvo) {
    // Copia os valores salvos para as variáveis atuais
    *PC = salvo->cop_PC;
    *reg_dado = salvo->cop_RGdados;
    *reg_A = salvo->cop_RGa;
    *reg_B = salvo->cop_RGb;
    *estado_atual = salvo->cop_estado_c;


    // Copia o banco de registradores salvo
    for (int i = 0; i < 8; i++) {
        banco_de_registradores[i] = salvo->cop_banco_de_registradores[i];
    }

    // Copia a memória de instruções salva
    for (int i = 0; i < 256; i++) {
        nome_inst[i] = salvo->cop_memoria[i];
    }

    // Copia o estado da ULA salvo
    *saida = salvo->cop_saida;

    // Copia a instrução atual salva
    *RI = salvo->cop_RI;

    printf("Estado restaurado.\n");
}

// Inicializa a pilha, definindo o topo como NULL (vazia)
void criarPilha(struct Pilha *p) {
    p->topo = NULL;
}

// Insere um novo nodo na pilha com o estado atual do processador salvo dentro dele
void inserir(struct Pilha *p, int *PC, struct instrucao *nome_inst, int *banco_de_registradores, int *reg_dado, int *reg_A, int *reg_B, 
             int *estado_atual, struct instrucao *RI, struct instrucao *cop_RI, struct ULA_saida *saida, struct ULA_saida *cop_saida) {
    // Aloca memória para o novo nodo da pilha
    struct nodo *novoNodo = (struct nodo *) malloc(sizeof(struct nodo));
    
    // Salva o estado atual do processador no campo 'estado' do novo nodo
    salvar_estado(PC, nome_inst, reg_dado, reg_A, reg_B, estado_atual, banco_de_registradores, saida, RI, &novoNodo->estado, cop_RI, cop_saida);

    // O próximo nodo do novo é o antigo topo da pilha
    novoNodo->prox = p->topo;
    
    // O novo nodo passa a ser o topo da pilha
    p->topo = novoNodo;
}

// Remove o nodo do topo da pilha, restaurando o estado salvo nele para o processador atual
void remover_nodo(struct Pilha *p, int *PC, struct instrucao *nome_inst, int *banco_de_registradores, int *reg_dado, int *reg_A, int *reg_B, 
                  int *estado_atual, struct instrucao *RI, struct instrucao *cop_RI, struct ULA_saida *saida, struct ULA_saida *cop_saida) {
    // Nodo que será removido (topo da pilha)
    struct nodo *nodo_removido = p->topo;
    
    if (nodo_removido == NULL) {
        printf("Pilha vazia, nada para remover.\n");
        return;
    }

    // Restaura o estado salvo no nodo para o processador
    restaurar_estado(PC, reg_dado, reg_A, reg_B, estado_atual, banco_de_registradores, nome_inst, saida, RI, &nodo_removido->estado);

    // Atualiza o topo da pilha para o próximo nodo
    p->topo = nodo_removido->prox;

    // Libera a memória do nodo removido
    free(nodo_removido);
}


void Visualizar_Instrucao_Atual(struct instrucao *RI){

            if(RI->opcode == 0){
                if(RI->funct == 0){
                    printf("\tadd $t%d, $t%d, $t%d\n", RI->rd, RI->rs, RI->rt);
                }
                else if(RI->funct == 2){
                    printf("\tsub $t%d, $t%d, $t%d\n", RI->rd, RI->rs, RI->rt);
                }
                else if(RI->funct == 4){
                    printf("\tand $t%d, $t%d, $t%d\n", RI->rd, RI->rs, RI->rt);
                }
                else if(RI->funct == 5){
                    printf("\tor $t%d, $t%d, $t%d\n", RI->rd, RI->rs, RI->rt);
                }
            }
            else if(RI->opcode == 4){
                    printf("\taddi $t%d, $t%d, %d\n", RI->rt, RI->rs, RI->imm);
            }else if(RI->opcode == 11){
                    printf("\tlw $t%d, %d($t%d)\n", RI->rt,RI->imm, RI->rs);
            }else if(RI->opcode == 15){
                    printf("\tsw $t%d, %d($t%d)\n", RI->rt, RI->imm, RI->rs);
            }else if(RI->opcode == 8){
                    printf("\tbeq $t%d, $t%d, %d\n", RI->rs, RI->rt, RI->imm);
            }else if(RI->opcode == 2){
                    printf("\tj %d\n", RI->addr);
            }
        printf("\n");
}

void imprime_estado(int *reg_dado, struct ULA_saida *saida, int *reg_A, int *reg_B, int *estado_atual, struct instrucao *RI, int *banco_de_registradores){
    printf("\t********ESTADO ATUAL [%d]********\n\n", *estado_atual);
    printf("\tRegistrador de Instrução (RI): %s\n", RI->inst_char); // <- Adicionado

    if (*estado_atual == 0) {
        if (RI->opcode == -1) {
            // Instrução inválida
        } else if (RI->opcode == 0) {
            printf("\tTipo R - opcode: %d, rs: %d, rt: %d, rd: %d, funct: %d\n", RI->opcode, RI->rs, RI->rt, RI->rd, RI->funct);
        } else if (RI->opcode == 2) {
            printf("\tTipo J - opcode: %d, addr: %d\n", RI->opcode, RI->addr);
        } else if (RI->opcode == 8) {
            printf("\tTipo I - opcode: %d, rs: %d, rt: %d, imm: %d\n", RI->opcode, RI->rs, RI->rt, RI->imm);
        } else if (RI->opcode == 15) {
            printf("\tTipo I - opcode: %d, rs: %d, rt: %d, imm: %d\n", RI->opcode, RI->rs, RI->rt, RI->imm);
        } else if (RI->opcode == 11) {
            printf("\tTipo I - opcode: %d, rs: %d, rt: %d, imm: %d\n", RI->opcode, RI->rs, RI->rt, RI->imm);
        } else if (RI->opcode == 4) {
            printf("\tTipo I - opcode: %d, rs: %d, rt: %d, imm: %d\n", RI->opcode, RI->rs, RI->rt, RI->imm);
        } else {
            printf("Tipo de instrução inválida!\n");
        }
    } else {
        Visualizar_Instrucao_Atual(RI);
        
           printf("\tRegistrador A $t%d[%d]\n", RI->rs, *reg_A);
            printf("\tRegistrador B $t%d[%d]\n", RI->rt, *reg_B);
            printf("\tRegistrador da ULA [%d]\n", saida->reg_ULA);
             printf("\tRegistrador de dados [%d]\n", *reg_dado);
      if (*estado_atual == 3) {
            printf("\tRegistrador de dados [%d]\n", *reg_dado);
        } else if (*estado_atual == 4 || *estado_atual == 8) {
            Imprimir_bancoRG(banco_de_registradores);
        } else if (*estado_atual == 5) {
            Imprimir_bancoRG(banco_de_registradores);
            printf("\tDado escrito [%d]\n", *reg_dado);
            printf("\tRegistrador da ULA [%d]\n", saida->reg_ULA);
        } else if (*estado_atual == 6) {
            Imprimir_bancoRG(banco_de_registradores);
            printf("\tDado escrito [%d]\n", saida->reg_ULA);
            printf("\tRegistrador da ULA [%d]\n", saida->reg_ULA);
        } else if (*estado_atual == 7) {
            printf("\tRegistrador da ULA [%d]\n", saida->reg_ULA);
        } else if (*estado_atual == 9) {
            printf("\tsaida flag [%d]\n", saida->flag);
        }
    }
}

void imprime_simulador(int *reg_dado, struct ULA_saida *saida, int *reg_A, int *reg_B, int *estado_atual, struct instrucao *RI){
    printf("\tRegistrador de Instrução (RI): %s\n", RI->inst_char); // <- Adicionado
    printf("\topcode: %d, rs: %d, rt: %d, rd: %d, funct: %d, imm: %d, addr: %d\n",
           RI->opcode, RI->rs, RI->rt, RI->rd, RI->funct, RI->imm, RI->addr);
    printf("\tRegistrador de dados [%d]\n", *reg_dado);
    printf("\tRegistrador A $t%d[%d]\n", RI->rs, *reg_A);
    printf("\tRegistrador B $t%d[%d]\n", RI->rt, *reg_B);
    printf("\tRegistrador da ULA [%d]\n", saida->reg_ULA);
    printf("\tRegistrador da ULA_Flag [%d]\n", saida->flag);
    printf("\tEstado atual [%d]\n\n", *estado_atual);
}


void Liberar_P(struct Pilha *p) {
    while (p->topo != NULL) {
        struct nodo *nodo_atual = p->topo;
        p->topo = p->topo->prox; // Vai para o próximo nó
        free(nodo_atual);
    }
}

void Salvar_Instrucoes_Asm(struct instrucao *nome_inst) {
    char nome_arquivo[100];
    setbuf(stdin, NULL);
    printf("Digite o nome do arquivo para salvar (ex: Salvar.asm): ");
    fgets(nome_arquivo, sizeof(nome_arquivo), stdin); // NOVO: Lê o nome digitado
    nome_arquivo[strcspn(nome_arquivo, "\n")] = 0; // Remove o \n do final

    FILE *arquivo = fopen(nome_arquivo, "w");  // MODIFICADO: Usa o nome escolhido pelo usuário

    if (arquivo == NULL) {
        printf("Erro ao abrir arquivo para escrita.\n");
        return;
    }

    // Escrever as instruções no formato Assembly
    for (int i = 0; i < 128; i++) {
        if (nome_inst[i].opcode == -1) {
            continue;  // Pula as instruções não utilizadas
        }

        // Tipo R (operadores como ADD, SUB, AND, OR)
        if (nome_inst[i].opcode == 0) {
            switch (nome_inst[i].funct) {
                case 0: fprintf(arquivo, "add $t%d, $t%d, $t%d\n", nome_inst[i].rd, nome_inst[i].rs, nome_inst[i].rt); break;
                case 2: fprintf(arquivo, "sub $t%d, $t%d, $t%d\n", nome_inst[i].rd, nome_inst[i].rs, nome_inst[i].rt); break;
                case 4: fprintf(arquivo, "and $t%d, $t%d, $t%d\n", nome_inst[i].rd, nome_inst[i].rs, nome_inst[i].rt); break;
                case 5: fprintf(arquivo, "or $t%d, $t%d, $t%d\n", nome_inst[i].rd, nome_inst[i].rs, nome_inst[i].rt); break;
            }
        }
        // Tipo I
        else if (nome_inst[i].opcode == 11) {  // LW
            fprintf(arquivo, "lw $t%d, %d($t%d)\n", nome_inst[i].rt, nome_inst[i].imm, nome_inst[i].rs);
        }
        else if (nome_inst[i].opcode == 15) {  // SW
            fprintf(arquivo, "sw $t%d, %d($t%d)\n", nome_inst[i].rt, nome_inst[i].imm, nome_inst[i].rs);
        }
        else if (nome_inst[i].opcode == 4) {  // ADDI
            fprintf(arquivo, "addi $t%d, $t%d, %d\n", nome_inst[i].rt, nome_inst[i].rs, nome_inst[i].imm);
        }
        else if (nome_inst[i].opcode == 8) {  // BEQ
            fprintf(arquivo, "beq $t%d, $t%d, %d\n", nome_inst[i].rs, nome_inst[i].rt, nome_inst[i].imm);
        }
        // Tipo J
        else if (nome_inst[i].opcode == 2) {  // J
            fprintf(arquivo, "j %d\n", nome_inst[i].addr);
        }
    }

    fclose(arquivo);  // Fecha o arquivo
    printf("Instruções salvas no arquivo %s\n", nome_arquivo); // MODIFICADO: mostra nome escolhido
}


void Salvar_Memoria_Dados(struct instrucao *nome_inst) {  // MODIFICADO: struct instrucao para multiciclo

    char nome_arquivo[100];
    setbuf(stdin, NULL);
    printf("Digite o nome do arquivo para salvar os dados (ex: Salvar.dat): ");
    fgets(nome_arquivo, sizeof(nome_arquivo), stdin); // NOVO: lê o nome do usuário
    nome_arquivo[strcspn(nome_arquivo, "\n")] = 0;    // NOVO: remove \n do final

    FILE *arquivo = fopen(nome_arquivo, "w"); // MODIFICADO: usa nome escolhido

    if (arquivo == NULL) {
        printf("Erro ao abrir arquivo para escrita.\n");
        return;
    }

    // Salva apenas a memória de dados (endereços 128 a 255)
    for (int i = 128; i < 256; i++) { // MODIFICADO: faixa de dados do multiciclo
        fprintf(arquivo, "%d:%d\n", i, nome_inst[i].dado); // MODIFICADO: pega .dado do multiciclo
    }

    fclose(arquivo);
    printf("Memória de dados salva no arquivo %s\n", nome_arquivo); // MODIFICADO: exibe nome usado
}


  void executar_RUN(
    struct Pilha *p,
    int *PC,
    struct instrucao *nome_inst,
    int *banco_de_registradores,
    int *reg_dado,
    int *reg_A,
    int *reg_B,
    int *estado_atual,
    struct instrucao *RI,
    struct instrucao *cop_RI,
    struct ULA_saida *saida,
    struct ULA_saida *cop_saida,
    int memoria_carregada
) {
    if (!memoria_carregada) {
        printf("[Erro] Memória não carregada!\n");
        return;
    }

    int executado[128] = {0}; // Marca os PCs já visitados


    *PC = 0; // Garante que começa do início
    *estado_atual = 0;

    // Salva o estado inicial na pilha
    inserir(p, PC, nome_inst, banco_de_registradores, reg_dado, reg_A, reg_B,
            estado_atual, RI, cop_RI, saida, cop_saida);

    while (*PC < 128 && nome_inst[*PC].opcode != -1 && executado[*PC] == 0) {
        *estado_atual = 0;
        executado[*PC] = 1;

        do {
            inserir(p, PC, nome_inst, banco_de_registradores, reg_dado, reg_A, reg_B,
                    estado_atual, RI, cop_RI, saida, cop_saida);

            Executar_Ciclo(reg_dado, saida, reg_A, reg_B, estado_atual, PC, RI,
                           nome_inst, banco_de_registradores);

            imprime_estado(reg_dado, saida, reg_A, reg_B, estado_atual, RI,
                           banco_de_registradores);

            ESTADOS(estado_atual, RI);

            printf("\nPC = %i\n", *PC);

        } while (*estado_atual != 0);
    }
}
