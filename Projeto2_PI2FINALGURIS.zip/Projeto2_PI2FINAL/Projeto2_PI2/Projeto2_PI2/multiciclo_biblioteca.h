struct instrucao {
    char inst_char[17];
    char dado_char[17];
    int opcode;
    int rs;
    int rt;
    int rd;
    int funct;
    int imm;
    int addr;
    int dado; // já tinha o campo de dado
};

struct ULA_saida {
    int reg_ULA;
    int flag;
};

struct estado_salvo {
    int cop_PC;
    int cop_RGdados;
    int cop_RGa;
    int cop_RGb;
    int cop_estado_c;
    int cop_banco_de_registradores[8];
    struct instrucao cop_memoria[256];
    struct ULA_saida cop_saida;
    struct instrucao cop_RI;
};

struct nodo{
    struct estado_salvo estado;
    struct nodo *prox;
};

struct Pilha{
    struct nodo *topo;
};



void Carregar_Memoria_Instrucoes_e_Dados(struct instrucao *nome_inst);

int Ler_Registrador(int *banco_de_registradores, int indice);

void Escrever_Registrador(int *banco_de_registradores, int indice, int valor);

void Imprimir_bancoRG(int *banco_de_registradores);

int Ler_M_Dados(int endereco, struct instrucao *nome_inst);

void Escrever_M_Dados(int endereco, int valor, struct instrucao *nome_inst);

void Imprimir_Memorias_Instrucoes_e_Dados(struct instrucao *nome_inst);

void Executar_Ciclo(
    int *reg_dado,
    struct ULA_saida *saida,
    int *reg_A,
    int *reg_B,
    int *estado_atual,
    int *PC,
    struct instrucao *RI,
    struct instrucao *nome_inst,
    int *banco_de_registradores
);

int NovaULA(int *reg_A, int *reg_B, int operacao, int *estado_atual, int* PC, struct instrucao *RI, struct ULA_saida *saida);    

void ESTADOS(int *estado_atual, struct instrucao *RI);

void salvar_estado( int *PC,struct instrucao *nome_inst, int *reg_dado, int *reg_A, int *reg_B, int *estado_atual, int *banco_de_registradores, struct ULA_saida *saida, struct instrucao *RI, struct estado_salvo *salvo, struct instrucao *copia_RI, struct ULA_saida *copia_saida);

void restaurar_estado( int *PC, int *reg_dado, int *reg_A, int *reg_B, int *estado_atual, int *banco_de_registradores, struct instrucao *nome_inst, struct ULA_saida *saida, struct instrucao *RI,  struct estado_salvo *salvo);

void criarPilha(struct Pilha *p);

void inserir(struct Pilha *p, int *PC, struct instrucao *nome_inst, int *banco_de_registradores, int *reg_dado, int *reg_A, int *reg_B, int *estado_atual, struct instrucao *RI, struct instrucao *cop_RI, struct ULA_saida *saida, struct ULA_saida *cop_saida);

void remover_nodo(struct Pilha *p, int *PC, struct instrucao *nome_inst, int *banco_de_registradores, int *reg_dado, int *reg_A, int *reg_B, int *estado_atual, struct instrucao *RI, struct instrucao *cop_RI, struct ULA_saida *saida, struct ULA_saida *cop_saida);

void Executar_Instrucao(int *reg_A, int *reg_B, int *estado_atual, int *PC, struct instrucao *RI, struct ULA_saida *saida);

void Visualizar_Instrucao_Atual(struct instrucao *RI);

void imprime_estado(int *reg_dado, struct ULA_saida *saida, int *reg_A, int *reg_B, int *estado_atual, struct instrucao *RI, int *banco_de_registradores);

void imprime_simulador(int *reg_dado, struct ULA_saida *saida, int *reg_A, int *reg_B, int *estado_atual, struct instrucao *RI);

void Liberar_P(struct Pilha *p);


void Salvar_Instrucoes_Asm(struct instrucao *nome_inst);

void Salvar_Memoria_Dados(struct instrucao *nome_inst);


void executar_RUN(
    struct Pilha *p,
    int *PC,
    struct instrucao *nome_inst,
    int *banco_de_registradores,
    int *reg_dado,
    int *reg_A,
    int *reg_B,
    int *estado_atual,
    struct instrucao *RI,
    struct instrucao *cop_RI,
    struct ULA_saida *saida,
    struct ULA_saida *cop_saida,
    int memoria_carregada
);