#include <stdio.h>
#include <stdlib.h>
#include <string.h> 
#include "multiciclo_biblioteca.h"

int main() {
    struct instrucao *nome_inst = malloc(256 * sizeof(struct instrucao));
    struct ULA_saida saida;
    struct ULA_saida cop_saida;
    struct instrucao RI;
    struct instrucao cop_RI;
    struct Pilha p;

    int banco_de_registradores[8] = {0};
    int reg_dado = 0;
    int reg_A = 0;
    int reg_B = 0;
    int estado_atual = 0;
    int PC = 0;
    int memoria_carregada = 0;
    int op;
    int tam = 0;

    criarPilha(&p);

    do {
        printf("\n==== MENU ====\n");
        printf("1 - Carregar Memória\n");
        printf("2 - Imprimir Memória\n");
        printf("3 - Imprimir Banco de Registradores\n");
        printf("4 - Executar um ciclo(STEP)\n");
        printf("5- Imprimir todo o simulador\n");
        printf("6- Voltar um ciclo(BACK)\n ");
        printf("7- Salvar .ASM\n");
        printf("8-Salvar Dados da memoria .DAT\n");
        printf("0 - Sair\n");
        printf("Escolha: ");
        scanf("%d", &op);

        switch (op) {
            case 1:
                Carregar_Memoria_Instrucoes_e_Dados(nome_inst);
                memoria_carregada = 1;
                printf("[OK] Memória carregada.\n");
                 inserir(&p, &PC, nome_inst, banco_de_registradores, &reg_dado, &reg_A, &reg_B, &estado_atual, &RI, &cop_RI, &saida, &cop_saida);
                     Executar_Ciclo(&reg_dado, &saida, &reg_A, &reg_B, &estado_atual, &PC, &RI, nome_inst, banco_de_registradores);
                    imprime_estado(&reg_dado, &saida, &reg_A, &reg_B, &estado_atual, &RI, banco_de_registradores);
                    ESTADOS(&estado_atual, &RI);

                    printf("\nPC = %i\n",PC);

                break;

            case 2:
                if (memoria_carregada) {
                    printf("[Memória de Instruções/Dados]\n");
                    Imprimir_Memorias_Instrucoes_e_Dados(nome_inst);
                } else {
                    printf("[Erro] Memória não carregada!\n");
                }
                break;

            case 3:
                Imprimir_bancoRG(banco_de_registradores);
                break;

            case 4:
                if (memoria_carregada) {
                   inserir(&p, &PC, nome_inst, banco_de_registradores, &reg_dado, &reg_A, &reg_B, &estado_atual, &RI, &cop_RI, &saida, &cop_saida);
                     Executar_Ciclo(&reg_dado, &saida, &reg_A, &reg_B, &estado_atual, &PC, &RI, nome_inst, banco_de_registradores);
                    imprime_estado(&reg_dado, &saida, &reg_A, &reg_B, &estado_atual, &RI, banco_de_registradores);
                    ESTADOS(&estado_atual, &RI);

                    printf("\nPC = %i\n",PC);

                } else {
                    printf("[Erro] Memória não carregada!\n");
                }
                break;

                case 5: 
                  printf("\t********PC Atual********\n\n");
                printf("\tPC = %d\n\n", PC);
                printf("\t********Registradores********\n\n");
                imprime_simulador(&reg_dado, &saida, &reg_A, &reg_B, &estado_atual, &RI);
                printf("\t********Instrucao Atual********\n\n");
                Visualizar_Instrucao_Atual(&RI);
                Imprimir_bancoRG(banco_de_registradores);
                
                break;

               case 6: 
                 if(PC == 0){
                    printf("\nenhuma instrução executada para retornar\n\n");
                }
                else{
                     remover_nodo(&p, &PC, nome_inst, banco_de_registradores,  &reg_dado, &reg_A, &reg_B, &estado_atual, &RI, &cop_RI, &saida, &cop_saida);
                     imprime_estado(&reg_dado, &saida, &reg_A, &reg_B, &estado_atual, &RI, banco_de_registradores);
                     printf("\tPC = %d\n", PC);
                }
                    
                break;

            case 7:
                if (memoria_carregada == 1) {
                Salvar_Instrucoes_Asm(nome_inst);  
            } else {
                printf("Memoria de instrucoes nao carregada!\n");
            }
            break;
        case 8:
    if (memoria_carregada == 1) {
         Salvar_Memoria_Dados(nome_inst);  
            } else {
                printf("Memoria de instrucoes nao carregada!\n");
            }
            break;
                break;
 case 9: 

  executar_RUN(&p, &PC, nome_inst, banco_de_registradores, &reg_dado,
             &reg_A, &reg_B, &estado_atual, &RI, &cop_RI, &saida, &cop_saida, memoria_carregada);

    break;

            case 0:
                printf("Encerrando programa.\n");
                break;

            default:
                printf("[Erro] Opção inválida.\n");
                break;
        }
    } while (op != 0);

    free(nome_inst);
    Liberar_P(&p);
    return 0;
}

