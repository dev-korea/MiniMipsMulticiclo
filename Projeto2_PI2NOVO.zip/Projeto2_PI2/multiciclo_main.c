#include <stdio.h>
#include <stdlib.h>
#include <string.h> 
#include "multiciclo_biblioteca.h"

int main() {
    struct instrucao *nome_inst = malloc(256 * sizeof(struct instrucao));
    int banco_de_registradores[8] = {0};

    int reg_dado = 0;
    int reg_A = 0;
    int reg_B = 0;
    int estado_atual = 0;
    struct ULA_saida saida;
    struct instrucao RI;
    int PC = 0;
    int memoria_carregada = 0;
    int op;

    do {
        printf("\n==== MENU ====\n");
        printf("1 - Carregar Memória\n");
        printf("2 - Imprimir Memória\n");
        printf("3 - Imprimir Banco de Registradores\n");
        printf("0 - Sair\n");
        printf("Escolha: ");
        scanf("%d", &op);

        switch (op) {
            case 1:
                Carregar_Memoria_Instrucoes_e_Dados(nome_inst);
                memoria_carregada = 1;
                printf("[OK] Memória carregada.\n");
                break;

            case 2:
                if (memoria_carregada) {
                    printf("[Memória de Instruções/Dados]\n");
                    Imprimir_Memorias_Instrucoes(nome_inst);
                } else {
                    printf("[Erro] Memória não carregada!\n");
                }
                break;

            case 3:
                Imprimir_bancoRG(banco_de_registradores);
                break;

            case 0:
                printf("Encerrando programa.\n");
                break;

            default:
                printf("[Erro] Opção inválida.\n");
                break;
        }
    } while (op != 0);

    free(nome_inst);
    return 0;
}

