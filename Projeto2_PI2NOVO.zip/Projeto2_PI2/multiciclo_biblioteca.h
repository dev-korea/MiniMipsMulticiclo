struct instrucao {
    char inst_char[17];
    char dado_char[9];
    int opcode;
    int rs;
    int rt;
    int rd;
    int funct;
    int imm;
    int addr;
    int dado; // já tinha o campo de dado
};

struct ULA_saida {
    int reg_ULA;
    int flag;
};

void Carregar_Memoria_Instrucoes_e_Dados(struct instrucao *nome_inst);

int novaULA(int A, int B, int operacao, int* zero);

int Ler_Registrador(int *banco_de_registradores, int indice);

void Escrever_Registrador(int *banco_de_registradores, int indice, int valor);

void Imprimir_bancoRG(int *banco_de_registradores);

int Ler_M_Dados(int endereco, struct instrucao *nome_inst);

void Escrever_M_Dados(int endereco, int valor, struct instrucao *nome_inst);

void Imprimir_Memorias_Instrucoes(struct instrucao *nome_inst);
